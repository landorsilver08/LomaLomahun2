package me.vripper.model

data class LoggedUser(val user: String)