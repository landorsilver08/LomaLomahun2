package me.vripper.model

data class ThreadPostId(val threadId: Long, val postId: Long)
