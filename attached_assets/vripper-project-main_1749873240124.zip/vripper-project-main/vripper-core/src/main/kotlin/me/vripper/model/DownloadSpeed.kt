package me.vripper.model

import kotlinx.serialization.Serializable

@Serializable
data class DownloadSpeed(val speed: Long)
