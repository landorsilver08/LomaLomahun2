package me.vripper.exception

class ValidationException(message: String) : Exception(message)