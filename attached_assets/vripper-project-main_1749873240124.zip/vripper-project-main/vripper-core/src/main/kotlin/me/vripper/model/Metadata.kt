package me.vripper.model

import me.vripper.entities.MetadataEntity

typealias Metadata = MetadataEntity