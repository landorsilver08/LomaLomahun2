package me.vripper.model

import me.vripper.entities.LogEntryEntity

typealias LogEntry = LogEntryEntity