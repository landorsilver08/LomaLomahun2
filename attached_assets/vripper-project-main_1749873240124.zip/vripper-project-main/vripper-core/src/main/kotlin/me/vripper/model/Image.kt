package me.vripper.model

import me.vripper.entities.ImageEntity

typealias Image = ImageEntity