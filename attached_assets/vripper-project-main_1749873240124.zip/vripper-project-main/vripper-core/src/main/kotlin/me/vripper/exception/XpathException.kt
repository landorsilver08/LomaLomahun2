package me.vripper.exception

class XpathException(e: Throwable?) : Exception(e)