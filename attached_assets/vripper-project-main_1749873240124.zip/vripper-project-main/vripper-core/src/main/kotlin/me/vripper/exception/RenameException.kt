package me.vripper.exception

class RenameException(message: String?, e: Exception?) : Exception(message, e)