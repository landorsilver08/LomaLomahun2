package me.vripper.model

import me.vripper.entities.ThreadEntity

typealias Thread = ThreadEntity