package me.vripper.model

import kotlinx.serialization.Serializable

@Serializable
data class ErrorCount(val count: Int)
