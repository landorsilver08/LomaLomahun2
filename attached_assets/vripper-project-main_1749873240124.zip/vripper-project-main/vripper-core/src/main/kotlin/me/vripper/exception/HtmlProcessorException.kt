package me.vripper.exception

class HtmlProcessorException(e: Throwable?) : Exception(e)