package me.vripper.web.restendpoints.domain

data class ScanRequest(val links: String?)