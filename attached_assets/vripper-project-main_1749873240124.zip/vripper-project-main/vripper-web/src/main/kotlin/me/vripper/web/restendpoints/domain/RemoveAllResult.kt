package me.vripper.web.restendpoints.domain

data class RemoveAllResult(val postIds: List<String>)