package me.vripper.web.restendpoints.domain

data class PostId(val postId: String)