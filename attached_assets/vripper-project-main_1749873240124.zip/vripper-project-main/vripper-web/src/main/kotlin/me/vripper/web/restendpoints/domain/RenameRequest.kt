package me.vripper.web.restendpoints.domain

data class RenameRequest(val postId: Long, val name: String)
