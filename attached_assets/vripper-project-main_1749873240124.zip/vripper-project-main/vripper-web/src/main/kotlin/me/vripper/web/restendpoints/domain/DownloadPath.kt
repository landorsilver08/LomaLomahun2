package me.vripper.web.restendpoints.domain

data class DownloadPath(val path: String)