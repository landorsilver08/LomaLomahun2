package me.vripper.web.restendpoints.domain

data class RemoveResult(val postId: String)