package me.vripper.web.restendpoints.domain

data class ThreadId(val threadId: String)