package me.vripper.web.restendpoints.domain

data class AltPostName(val postId: String, val altName: String)