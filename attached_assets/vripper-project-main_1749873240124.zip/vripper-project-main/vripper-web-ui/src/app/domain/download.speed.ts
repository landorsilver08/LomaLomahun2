export class DownloadSpeed {
  constructor(public speed: number) {}
}
