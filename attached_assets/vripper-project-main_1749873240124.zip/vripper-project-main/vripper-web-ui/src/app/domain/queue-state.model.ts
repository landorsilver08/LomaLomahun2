export class QueueState {
  constructor(public running: number, public remaining: number) {}
}
