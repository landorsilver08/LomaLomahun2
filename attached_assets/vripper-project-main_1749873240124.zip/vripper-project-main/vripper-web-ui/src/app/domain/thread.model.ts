export class Thread {
  constructor(
    public link: string,
    public title: string,
    public threadId: number,
    public total: number
  ) {}
}
