export class ErrorCount {
  constructor(public count: number) {}
}
