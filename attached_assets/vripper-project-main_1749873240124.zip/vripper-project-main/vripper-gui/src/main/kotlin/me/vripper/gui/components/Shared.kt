package me.vripper.gui.components

import javafx.beans.property.SimpleStringProperty

object Shared {
    val searchInput = SimpleStringProperty()
}